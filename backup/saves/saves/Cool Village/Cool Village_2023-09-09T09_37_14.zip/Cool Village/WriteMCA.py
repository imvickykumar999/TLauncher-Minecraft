
from CallMe import MAZE3D_generator as mzg
from CallMe import MAZE3D_solver as mzs

import anvil
import math

region = anvil.EmptyRegion(0, 0)
chunk = 1

tall = 250
side = 16*chunk -1

# wall = anvil.Block('minecraft', 'gold_block')
wall = anvil.Block('minecraft', 'glowstone')

floor = anvil.Block('minecraft', 'diamond_block')
# floor = anvil.Block('minecraft', 'blue_stained_glass')

us_maze = mzg.returnMaze(side,side)
# print(us_maze) # UNsolved

s_maze = mzs.solve_maze(us_maze)
# print(s_maze) # Solved

# if us_maze[z][x] == 'p':

for x in range(side): # floor
    for y in range(-63, tall, 5):
        for z in range(side):
            if y == -63 or not (x == 1 and z == 1):
                region.set_block(floor, x, y, z)

for x in range(side): # walls
    for y in range(-63, tall-1):
        for z in range(side):
            if (x == 0 or x == side - 1 or z == 0 or z == side - 1):
                region.set_block(wall, x, y, z)

region.save('region/r.0.0.mca')
print('\nBuild Complete.')
